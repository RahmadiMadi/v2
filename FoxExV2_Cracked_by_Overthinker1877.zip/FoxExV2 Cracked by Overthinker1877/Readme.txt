Run loginbypass.exe first and then execute the ExV2.py

Turn off real-time protection if crack is detected as virus.

-By Overthinker1877, 1877team